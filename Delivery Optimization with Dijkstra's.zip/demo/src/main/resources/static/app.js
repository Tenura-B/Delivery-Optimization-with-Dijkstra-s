
const OUTPUT_LOG = document.getElementById('output');
let map;
let routeLayer;
let markers = [];
const API_BASE = '/api/delivery'; // Matches your Spring Controller @RequestMapping


function logToOutput(message) {
    OUTPUT_LOG.innerHTML += `<p>${message}</p>`;
    OUTPUT_LOG.scrollTop = OUTPUT_LOG.scrollHeight;
}

async function handleAddTask() {
    const order = {
        orderId: document.getElementById('tfOrderId').value,
        destination: document.getElementById('tfTaskDest').value,
        initialDeadlineMinutes: parseInt(document.getElementById('tfTaskDeadline').value),
        importanceLevel: parseInt(document.getElementById('tfTaskImportance').value)
    };


    if (!order.orderId || !order.destination || isNaN(order.initialDeadlineMinutes) || isNaN(order.importanceLevel)) {
        logToOutput('<span class="log-error">Error: All order fields must be filled.</span>');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/order`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(order)
        });

        if (response.ok) {
            logToOutput(`<span class="log-success">✅ Order ${order.orderId} added to the queue.</span>`);
        } else {
            const errorText = await response.text();
            logToOutput(`<span class="log-error">❌ Error: ${errorText}</span>`);
        }
    } catch (e) {
        logToOutput('<span class="log-error">❌ Network Error: Could not connect to Java Backend.</span>');
    }
}



document.addEventListener('DOMContentLoaded', initMap);


let destinationMarkers = [];


const FIXED_LOCATIONS = {
    "DEPOT": [40.7306, -73.9866], // Lower Manhattan
    "A": [40.7580, -73.9855],     // Midtown
    "B": [40.7813, -73.9660],     // Upper East Side
    "C": [40.7128, -74.0060],     // Financial District
    "D": [40.7410, -73.9989]      // Chelsea
};
function initMap() {
    // Default coordinates: Central Manhattan area
    map = L.map('map').setView([40.7500, -73.9800], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);


    plotFixedDestinations();

    logToOutput('<span class="log-success">Map initialized.</span>');
}

function plotFixedDestinations() {
    for (const [name, coords] of Object.entries(FIXED_LOCATIONS)) {
        // Use a customized icon for permanent destinations
        const marker = L.marker(coords, {
            icon: L.divIcon({
                className: 'destination-marker',
                html: `<div style="background-color: #3f51b5; color: white; border-radius: 5px; padding: 3px 5px; font-weight: bold;">${name}</div>`,
                iconSize: [40, 20],
                iconAnchor: [20, 10]
            })
        }).bindPopup(`Destination: ${name}`).addTo(map);
        destinationMarkers.push(marker);
    }

    const bounds = L.featureGroup(destinationMarkers).getBounds();
    if (bounds.isValid()) {
        map.fitBounds(bounds);
    }
}


let vehicleMarker;


function clearMap() {
    if (routeLayer) {
        map.removeLayer(routeLayer);
    }

    markers.forEach(marker => map.removeLayer(marker));
    markers = [];


    if (vehicleMarker) {
        map.removeLayer(vehicleMarker);
        vehicleMarker = null;
    }
}


const vehicleIcon = L.divIcon({
    className: 'vehicle-icon',
    html: '<div style="font-size: 24px;">🚚</div>',
    iconSize: [24, 24]
});


function visualizeDispatch(result, delayMs) {

    const coordinates = result.gpsRoute;

    routeLayer = L.polyline(coordinates, {color: '#d32f2f', weight: 5, opacity: 0.8}).addTo(map);
    map.fitBounds(routeLayer.getBounds());


    if (!vehicleMarker) {
        vehicleMarker = L.marker(coordinates[0], { icon: vehicleIcon }).addTo(map);
    } else {
        vehicleMarker.setLatLng(coordinates[0]);
    }


    const totalSteps = 100;
    const stepDuration = (delayMs * 1000) / totalSteps;
    let step = 0;

    const interval = setInterval(() => {
        if (step >= coordinates.length - 1) {
            clearInterval(interval);
            // Move vehicle to the final coordinate
            vehicleMarker.setLatLng(coordinates[coordinates.length - 1]);
            return;
        }

        const start = coordinates[step];
        const end = coordinates[step + 1];

        const travelDistance = L.latLng(start).distanceTo(L.latLng(end));
        const durationPerSegment = (travelDistance / routeLayer.getBounds().getSouthWest().distanceTo(routeLayer.getBounds().getNorthEast())) * 1000; // Crude speed scaling


        setTimeout(() => {
            vehicleMarker.setLatLng(end);
        }, durationPerSegment);

        step++;
    }, 500);
}



async function handleStartSimulation() {
    const startLocation = document.getElementById('tfStartLocation').value;
    const congestionFactor = document.getElementById('tfCongestionFactor').value;

    OUTPUT_LOG.innerHTML = '';
    logToOutput("--- SIMULATION STARTED ---");
    clearMap();


    let response;

    try {
        const url = `${API_BASE}/simulate?startLocation=${encodeURIComponent(startLocation)}&congestionFactor=${encodeURIComponent(congestionFactor)}`;


        response = await fetch(url);

    } catch (e) {

        logToOutput(`❌ <span class="log-error">Network Error: Could not connect to Java Backend.</span>`);
        console.error("Fetch failed:", e);
        return;
    }


    if (!response.ok) {
        const errorBody = await response.text();
        logToOutput(`❌ <span class="log-error">Simulation failed (${response.status} ${response.statusText}): ${errorBody}</span>`);
        return;
    }


    const results = await response.json();

    if (results.length === 0) {
        logToOutput('Simulation ended: No routes dispatched. Queue was empty or routing failed.');
        return;
    }

    let totalTime = 0;


    let dispatchDelay = 0;
    const DISPATCH_INTERVAL_MS = 1500;

    results.forEach(result => {
        setTimeout(() => {
            logToOutput(`
                <span style="color: #3f51b5; font-weight: bold;">🚚 DISPATCHING ${result.orderId}</span> 
                | DPS: ${result.dps.toFixed(2)} 
                | Time: ${result.travelTime} min (End: ${result.startTime + result.travelTime} min)
                <br>   Route: ${result.route.join(' &rarr; ')}
            `);

            drawRouteOnMap(result);


            if (result === results[results.length - 1]) {

                totalTime = result.startTime + result.travelTime;
                setTimeout(() => {
                    logToOutput(`<br><span style="font-size: 1.1em; font-weight: bold;">--- SIMULATION ENDED --- | Total Time: ${totalTime} min</span>`);
                }, 2000);
            }
        }, dispatchDelay);

        dispatchDelay += DISPATCH_INTERVAL_MS;
    });
}




function drawRouteOnMap(result) {
    clearMap();

e
    if (!vehicleMarker) {
        vehicleMarker = L.marker(result.gpsRoute[0], { icon: vehicleIcon }).addTo(map);
    } else {
        vehicleMarker.setLatLng(result.gpsRoute[0]);
    }


    routeLayer = L.polyline(result.gpsRoute, {color: '#d32f2f', weight: 5, opacity: 0.8}).addTo(map);


    const startMarker = L.marker(result.gpsRoute[0]).bindPopup(`Start: ${result.route[0]}`).addTo(map);
    const endMarker = L.marker(result.gpsRoute[result.route.length - 1]).bindPopup(`Destination: ${result.route[result.route.length - 1]}`).addTo(map);
    markers.push(startMarker, endMarker);


    setTimeout(() => {
        vehicleMarker.setLatLng(result.gpsRoute[result.gpsRoute.length - 1]);
    }, 2000);
}